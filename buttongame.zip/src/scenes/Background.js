// You can write more code here

/* START OF COMPILED CODE */

class Background extends Phaser.GameObjects.TileSprite {
  constructor(scene, x, y, width, height, texture, frame) {
    super(
      scene,
      x ?? 0,
      y ?? 0,
      width ?? 160,
      height ?? 240,
      texture || "background",
      frame
    );

    /* START-USER-CTR-CODE */
    // Write your code here.
    /* END-USER-CTR-CODE */
  }

  /* START-USER-CODE */

  // Write your code here.

  /* END-USER-CODE */
}

/* END OF COMPILED CODE */

// You can write more code here
